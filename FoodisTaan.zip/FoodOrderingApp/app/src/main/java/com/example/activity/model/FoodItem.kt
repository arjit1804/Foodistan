package com.example.activity.model

data class FoodItem(
    val id: String,
    val name: String,
    val cost_for_one: Int
)