package com.example.activity.model

class Faqs(
    val ques:String,
    val ans:String
)